DATABASES = {
    'default' : {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'dbs',                
        'USER': 'root',                          
        'PASSWORD': 'p@ssw0rd',          
        'HOST': 'localhost',                
        'PORT': '3306',                          
    }
}
SECRET_KEY = 'django-insecure-zlj^1a6m%5!y=3f&0m12v(k%#n=_kt5&rz*2q-)9&07t&#t=2)'